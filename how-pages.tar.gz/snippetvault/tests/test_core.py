import pytest

from snippetvault import core


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("Hello, World!", "hello-world"),
        ("  Foo   Bar__Baz  ", "foo-bar-baz"),
    ],
)
def test_slugify(text, expected):
    assert core.slugify(text) == expected


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("one two  three", 3),
        ("", 0),
    ],
)
def test_word_count(text, expected):
    assert core.word_count(text) == expected


def test_truncate_short_text_unchanged():
    assert core.truncate("abc", 10) == "abc"


def test_truncate_long_text_with_ellipsis():
    result = core.truncate("abcdefghij", 5)
    assert result == "abcd…"
    assert len(result) == 5


def test_reading_time():
    assert core.reading_time("word " * 400) == 2.0
