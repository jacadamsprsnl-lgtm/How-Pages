from click.testing import CliRunner

from snippetvault.cli import cli


def test_slugify_command():
    runner = CliRunner()
    result = runner.invoke(cli, ["slugify", "Hello World"])
    assert result.exit_code == 0
    assert result.output.strip() == "hello-world"


def test_stats_command():
    runner = CliRunner()
    result = runner.invoke(cli, ["stats", "one two three"])
    assert result.exit_code == 0
    assert "words: 3" in result.output


def test_truncate_command():
    runner = CliRunner()
    result = runner.invoke(cli, ["truncate", "--max-len", "3", "abcdef"])
    assert result.exit_code == 0
    assert result.output.strip() == "ab…"
