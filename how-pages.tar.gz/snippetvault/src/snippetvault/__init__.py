"""SnippetVault: tiny text utilities."""

__version__ = "0.1.0"
