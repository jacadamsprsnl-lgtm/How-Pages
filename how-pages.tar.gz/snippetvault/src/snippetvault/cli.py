"""Command-line interface for snippetvault."""

import click

from snippetvault import core


@click.group()
def cli():
    """SnippetVault: tiny text utilities."""


@cli.command()
@click.argument("text")
def slugify(text: str):
    """Convert TEXT into a slug."""
    click.echo(core.slugify(text))


@cli.command()
@click.argument("text")
def stats(text: str):
    """Show word count and reading time for TEXT."""
    words = core.word_count(text)
    minutes = core.reading_time(text)
    click.echo(f"words: {words}, reading_time: {minutes:.2f} min")


@cli.command()
@click.argument("text")
@click.option("--max-len", type=int, default=40, help="Maximum length.")
def truncate(text: str, max_len: int):
    """Truncate TEXT to --max-len characters."""
    click.echo(core.truncate(text, max_len))
