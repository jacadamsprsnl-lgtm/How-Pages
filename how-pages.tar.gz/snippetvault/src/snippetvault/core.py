"""Text processing utilities."""

import re


def slugify(text: str) -> str:
    """Convert text into a lowercase-hyphenated slug."""
    text = text.strip().lower()
    text = re.sub(r"[^\w\s-]", "", text)
    return re.sub(r"[\s_]+", "-", text)


def word_count(text: str) -> int:
    """Count whitespace-separated words."""
    return len(text.split())


def truncate(text: str, max_len: int, suffix: str = "…") -> str:
    """Truncate text to max_len characters, appending suffix if truncated."""
    if len(text) <= max_len:
        return text
    return text[: max_len - len(suffix)] + suffix


def reading_time(text: str, wpm: int = 200) -> float:
    """Estimate reading time in minutes for the given text."""
    return word_count(text) / wpm
