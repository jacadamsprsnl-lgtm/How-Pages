# snippetvault

Tiny text utilities CLI.

## Usage

```bash
snippetvault slugify "Hello, World!"
snippetvault stats "a few words here"
snippetvault truncate --max-len 10 "abcdefghijklmnop"
```

## Development

Install the project with dev dependencies:

```bash
python -m venv .venv
.venv/bin/pip install -e '.[dev]'
```

Run tests:

```bash
.venv/bin/python -m pytest
```

Lint, format, and type-check:

```bash
.venv/bin/ruff check .
.venv/bin/ruff format --check .
.venv/bin/mypy src tests
```

## Lock file

`requirements-lock.txt` pins all runtime + dev dependencies. It is generated
with [pip-tools](https://github.com/jazzband/pip-tools):

```bash
pip-compile --extra=dev --output-file=requirements-lock.txt pyproject.toml
```

To install from the lock:

```bash
pip install -r requirements-lock.txt
```
